$(document).ready(function(){
    $("#ashuchouhan").draggable();
    $("#ashu").droppable({
        accept:'#ashuchouhan',
        drop:function(event , ui){
            $(this).addClass("myCls").find("p").html("done")
        }
    })

})