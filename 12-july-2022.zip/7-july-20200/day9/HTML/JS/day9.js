function ddd(){
var imgsrc= document.getElementById('02').getAttribute('src');
document.getElementById('01').src=imgsrc;
}

function ddd1(){
    var imgsrc= document.getElementById('03').getAttribute('src');
    document.getElementById('01').src=imgsrc;
}

function ddd2(){
    var imgsrc= document.getElementById('04').getAttribute('src');
    document.getElementById('01').src=imgsrc;
}

    function ddd3(){
        var imgsrc= document.getElementById('05').getAttribute('src');
        document.getElementById('01').src=imgsrc;
}