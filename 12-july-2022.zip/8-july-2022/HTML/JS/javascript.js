function changefont(){
    document.getElementById('01').style.fontFamily="myfirstfont";
}
function chnagesize(){
    document.getElementById('01').style.fontSize = "60px";
}
function hidefont(){
    document.getElementById('01').style.display = "none";
}